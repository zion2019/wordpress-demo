<?php
/**
 * Template part for displaying the "Only Copyright" footer
 *
 * This is a fallback
 *
 * @see    template-parts/footers/footer-copyright.php
 * @link   https://codex.wordpress.org/Template_Hierarchy
 *
 * @author 8guild
 */
