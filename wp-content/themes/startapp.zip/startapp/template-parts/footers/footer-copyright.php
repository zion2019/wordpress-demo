<?php
/**
 * Template part for displaying the "Only Copyright" footer
 *
 * @author 8guild
 */
